import type { NavigationGuard } from 'vue-router'
export type MiddlewareKey = string
declare module "/home/jlabrada/Documents/sources/experiments/vue/nuxt3/nuxt3-tailwinds-storybook/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    middleware?: MiddlewareKey | NavigationGuard | Array<MiddlewareKey | NavigationGuard>
  }
}