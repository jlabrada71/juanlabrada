
    <template> 
      <div class="flex flex-col m-8 bg-slate-500 h-screen">
        <h1 class="text-5xl text-slate-50 font-bold p-4">Component List</h1>
        <div class="flex flex-col gap-4 m-8 bg-slate-200 p-4">
        <div class="flex flex-col gap-2 p-4 bg-slate-50"><span class="font-bold text-2xl">Welcome</span><Welcome></Welcome></div>
        </div>
      </div>
    </template>
  