var nav = {
	home: "Inicio",
	services: "Servicios",
	projects: "Proyectos",
	about: "Nosotros",
	contact: "Contacto"
};
var home = {
	title: "Servicios de Construcción Premier",
	subtitle: "Construyendo Excelencia Desde 1995",
	description: "Bienvenido a Premier Construction, su socio de confianza para todas sus necesidades de construcción y renovación. Con más de 25 años de experiencia, ofrecemos artesanía de calidad y servicio excepcional en cada proyecto.",
	services_title: "Nuestros Servicios",
	recent_work_title: "Nuestro Trabajo Reciente",
	why_choose_title: "¿Por Qué Elegir Premier Construction?",
	get_started_title: "Comience Hoy",
	get_started_description: "¿Listo para hacer realidad su visión de construcción? Contáctenos para una consulta y presupuesto gratuitos."
};
var services = {
	residential: {
		title: "Construcción Residencial",
		custom_homes: "Construcción de viviendas personalizadas",
		renovations: "Renovaciones y ampliaciones de hogar",
		kitchen_bath: "Remodelación de cocinas y baños",
		roofing: "Techado y revestimiento"
	},
	commercial: {
		title: "Construcción Comercial",
		office_buildings: "Edificios de oficinas y espacios comerciales",
		warehouse: "Instalaciones industriales y almacenes",
		restaurant: "Construcción de restaurantes y hoteles",
		tenant: "Mejoras para inquilinos"
	},
	specialized: {
		title: "Servicios Especializados",
		green_building: "Construcción ecológica y sostenible",
		historic: "Renovación y restauración histórica",
		emergency: "Reparaciones de emergencia y restauración",
		project_management: "Gestión de proyectos y consultoría"
	}
};
var features = {
	licensed: {
		title: "Licenciado y Asegurado",
		description: "Contratistas completamente licenciados con cobertura de seguro integral"
	},
	quality: {
		title: "Artesanía de Calidad",
		description: "Atención al detalle y materiales premium en cada proyecto"
	},
	delivery: {
		title: "Entrega a Tiempo",
		description: "Proyectos completados a tiempo y dentro del presupuesto"
	},
	satisfaction: {
		title: "Satisfacción del Cliente",
		description: "Calificaciones de 5 estrellas e innumerables clientes satisfechos"
	}
};
var contact = {
	phone: "Llámanos",
	email: "Email",
	office: "Oficina",
	credentials: "Licenciado • Afianzado • Asegurado"
};
var projects = {
	custom_home: {
		title: "Construcción de Casa Personalizada",
		description: "Hogar familiar moderno con materiales sostenibles y diseño energéticamente eficiente"
	},
	office_building: {
		title: "Edificio de Oficinas Comerciales",
		description: "Complejo de oficinas de última generación con arquitectura contemporánea"
	},
	kitchen_renovation: {
		title: "Renovación de Cocina",
		description: "Transformación completa de cocina con acabados de alta gama y electrodomésticos modernos"
	}
};
const es = {
	nav: nav,
	home: home,
	services: services,
	features: features,
	contact: contact,
	projects: projects
};

export { contact, es as default, features, home, nav, projects, services };
//# sourceMappingURL=es.mjs.map
