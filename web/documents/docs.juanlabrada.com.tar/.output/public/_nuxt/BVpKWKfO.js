import{b as r}from"./BKQ4KLzW.js";var e=4;function a(o){return r(o,e)}export{a as c};
