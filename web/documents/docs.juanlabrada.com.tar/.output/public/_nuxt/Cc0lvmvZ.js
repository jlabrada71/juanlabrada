import{k as n,l as e}from"./O6nj71kv.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
