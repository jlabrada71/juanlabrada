import{_ as o,o as r,c as t,j as n}from"./O6nj71kv.js";const s={};function c(e,a){return r(),t("strong",null,[n(e.$slots,"default")])}const _=o(s,[["render",c]]);export{_ as default};
