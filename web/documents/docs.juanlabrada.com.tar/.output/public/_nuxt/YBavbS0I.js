import{_ as o,o as r,c as t,j as s}from"./O6nj71kv.js";const c={};function n(e,a){return r(),t("tbody",null,[s(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
