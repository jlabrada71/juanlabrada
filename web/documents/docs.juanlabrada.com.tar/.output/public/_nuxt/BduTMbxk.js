import{_ as t,o as s,c as o,j as c}from"./O6nj71kv.js";const r={},n={class:"text-white"};function a(e,_){return s(),o("p",n,[c(e.$slots,"default")])}const f=t(r,[["render",a]]);export{f as default};
