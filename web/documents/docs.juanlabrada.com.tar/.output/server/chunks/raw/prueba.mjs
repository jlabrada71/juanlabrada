// ROLLUP_NO_REPLACE 
 const prueba = "{\"parsed\":{\"_path\":\"/prueba\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"Hello\",\"description\":\"\",\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"h1\",\"props\":{\"id\":\"hello\"},\"children\":[{\"type\":\"text\",\"value\":\"Hello\"}]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:prueba.md\",\"_source\":\"content\",\"_file\":\"prueba.md\",\"_stem\":\"prueba\",\"_extension\":\"md\"},\"hash\":\"bqvBbCxEiO\"}";

export { prueba as default };
//# sourceMappingURL=prueba.mjs.map
