// ROLLUP_NO_REPLACE 
 const about = "{\"parsed\":{\"_path\":\"/about\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"About Content v2\",\"description\":\"Back home\",\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"h1\",\"props\":{\"id\":\"about-content-v2\"},\"children\":[{\"type\":\"text\",\"value\":\"About Content v2\"}]},{\"type\":\"element\",\"tag\":\"p\",\"props\":{},\"children\":[{\"type\":\"element\",\"tag\":\"a\",\"props\":{\"href\":\"/\"},\"children\":[{\"type\":\"text\",\"value\":\"Back home\"}]}]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:about.md\",\"_source\":\"content\",\"_file\":\"about.md\",\"_stem\":\"about\",\"_extension\":\"md\"},\"hash\":\"JK1KNJDo4V\"}";

export { about as default };
//# sourceMappingURL=about.mjs.map
